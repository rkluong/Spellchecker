// HashSet.hpp
//
// ICS 46 Spring 2016
// Project #3: Set the Controls for the Heart of the Sun
//
// A HashSet is an implementation of a Set that is a separately-chained
// hash table, implemented as a dynamically-allocated array of linked
// lists.  At any given time, the HashSet has a "size" indicating
// how many elements are stored within it, along with a "capacity"
// indicating the size of the array.
//
// As elements are added to the HashSet and the proportion of the HashSet's
// size to its capacity exceeds 0.8 (i.e., there are more than 80% as many
// elements as there are array cells), the HashSet should be resized so
// that it is twice as large as it was before.
//
// You are not permitted to use the containers in the C++ Standard Library
// (such as std::vector, std::list, or std::array).  Instead, you'll need
// to use a dynamically-allocated array and your own linked list
// implementation; the linked list doesn't have to be its own class,
// though you can do that, if you'd like.

#ifndef HASHSET_HPP
#define HASHSET_HPP

#include <functional>
#include "Set.hpp"
#include <iostream>

template <typename T>
class LinkedList
{
public:
    // Default Constructor
    LinkedList();
    // Default Deconstructor
    virtual ~LinkedList();
    // Copy Constructor
    LinkedList(const LinkedList& s);
    // adds to the end of the LinkList
    void add(const T& element);

    // returns the size of the LinkList
    int size();
    // check if element is in the List
    bool contains(const T& element);
    // help copy to copy one LinkedList to another 
    void copyAll(const LinkedList& s);
    // indexing the LinkedList
    T get(int index);  
    // helper method destroy LinkedList
    virtual void destroyAll();
private:
    struct Node {
        T value = NULL;
        Node* next = nullptr;
    };

    // must init in constructor
    Node* head;
    Node* tail;
    int node_count = 0;
    
    
};

template <typename T>
LinkedList<T>::~LinkedList(){
    destroyAll();
}

template <typename T>
LinkedList<T>::LinkedList(const LinkedList& s){
    copyAll(s);
}

template <typename T>
void LinkedList<T>::copyAll(const LinkedList& s)
{
    Node* curr = s.head;
    while (curr != nullptr)
    {
        head = new Node{curr->value, head};
        curr = curr->next;
    }
}

template <typename T>
void LinkedList<T>::destroyAll()
{
    Node* curr = head;

    while (curr != nullptr)
    {
        Node* temp = curr;
        curr = curr->next;
        delete temp;
    }
}

template <typename T>
LinkedList<T>::LinkedList()
{
	head = nullptr;
    tail = nullptr;
}

template <typename T>
void LinkedList<T>::add(const T& element) {
	if(contains(element))
		return;
	if (!node_count) {
		head = new Node{element, nullptr};
		tail = head;
		node_count++;
		return;
	}
	
    tail->next = new Node{element, nullptr};
    tail = tail->next;
    node_count++;
}

template <typename T>
T LinkedList<T>::get(int index) {
    Node* node = head;
    for (int i = 0; i < node_count; i++) {
        if (i == index)
            return node->value;
        node = node->next;
    }
    return NULL;
}

template <typename T>
bool LinkedList<T>::contains(const T& element){
 
    Node* temp = head;
    while(temp != nullptr){
        if(temp->value == element){
            return true;
        }
        temp = temp->next;
    }
    return false;
}

template <typename T>
int LinkedList<T>::size(){
    return node_count;
}


template <typename T>
class HashSet : public Set<T>
{
public:
    // The default capacity of the HashSet before anything has been
    // added to it.
    static constexpr unsigned int DEFAULT_CAPACITY = 10;

    // A HashFunction 
    typedef std::function<unsigned int(const T&)> HashFunction;

public:
    // Initializes a HashSet to be empty, so that it will use the given
    // hash function whenever it needs to hash an element.
    HashSet(HashFunction hashFunction);

    // Cleans up the HashSet so that it leaks no memory.
    virtual ~HashSet();

    // Initializes a new HashSet to be a copy of an existing one.
    HashSet(const HashSet& s);

    // Assigns an existing HashSet into another.
    HashSet& operator=(const HashSet& s);


    // isImplemented() should be modified to return true if you've
    // decided to implement a HashSet, false otherwise.
    virtual bool isImplemented() const;


    // add() adds an element to the set.  If the element is already in the set,
    // this function has no effect.  This function triggers a resizing of the
    // array when the ratio of size to capacity would exceed 0.8.  In the case
    // where the array is resized, this function runs in linear time (with
    // respect to the number of elements, assuming a good hash function);
    // otherwise, it runs in constant time (again, assuming a good hash
    // function).
    virtual void add(const T& element);


    // contains() returns true if the given element is already in the set,
    // false otherwise.  This function runs in constant time (with respect
    // to the number of elements, assuming a good hash function).
    virtual bool contains(const T& element) const;


    // size() returns the number of elements in the set.
    virtual unsigned int size() const;

private:
    HashFunction hashFunction;
    LinkedList<T>** hash_table;
    int array_size = DEFAULT_CAPACITY;
    int capacity = 0;
    // helper to destroy HashSet
    void destroyAll();
    // helper to copy Hashset
    void copyAll(const HashSet& s);
    // fills LinkedList objects into the hashtable
    void fill_bucket(LinkedList<T>* table[], int table_size);
    // adds an element to the table
    void _add(LinkedList<T>* table[], int table_size, const T& element);
    // resizes the hash table
    void resize_table();
};



//constructor
template <typename T>
HashSet<T>::HashSet(HashFunction hashFunction)
    : hashFunction{hashFunction}
{
    hash_table = new LinkedList<T>* [array_size];
 	fill_bucket(hash_table, array_size);  
}


//deconstructor
template <typename T>
HashSet<T>::~HashSet()
{
    destroyAll();
}

template <typename T>
void HashSet<T>::destroyAll(){
	for(int i = 0; i < array_size; i++){
        delete hash_table[i];
   	}
  	delete [] hash_table;
}

//copy constructor
template <typename T>
HashSet<T>::HashSet(const HashSet& s): hashFunction{s.hashFunction}
{
	copyAll(s);
}

template <typename T>
void HashSet<T>::copyAll(const HashSet& s){
	capacity = 0;
	array_size = s.array_size;
    hash_table = new LinkedList<T>*[array_size];
    fill_bucket(hash_table, array_size);
    for (int b = 0; b < array_size; b++) {
        for(int i = 0; i < s.hash_table[b]->size(); i++) {
            T value = s.hash_table[b]->get(i);
            add(value);
        }
    }
}

//assignment operator
template <typename T>
HashSet<T>& HashSet<T>::operator=(const HashSet& s)
{
    if (this != &s)
    {
        hashFunction = s.hashFunction;
        destroyAll();
        copyAll(s);
    }

    return *this;
}


template <typename T>
bool HashSet<T>::isImplemented() const
{
    return true;
}

template <typename T>
void HashSet<T>::add(const T& element)
{
    float ratio = (float)capacity/(float)array_size;
    if (ratio > 0.8){
        resize_table();
    }
    _add(hash_table, array_size, element);
    capacity++;
}

template <typename T>
void HashSet<T>::_add(LinkedList<T>* table[], int table_size, const T& element){
    int bucket = hashFunction(element) % table_size;
    if(!table[bucket]->contains(element)) {
        table[bucket]->add(element);
    }

}


template <typename T>
bool HashSet<T>::contains(const T& element) const
{
    int index = hashFunction(element) % array_size;
    return hash_table[index]->contains(element);
}


template <typename T>
unsigned int HashSet<T>::size() const
{
    return capacity;
}

template <typename T>
void HashSet<T>::fill_bucket(LinkedList<T>* table[], int table_size){
    for(int i = 0; i < table_size; i++){
        table[i] = new LinkedList<T>;
    }
}

template <typename T>
void HashSet<T>::resize_table(){

    int newCap = array_size * 2;
    LinkedList<T>** newTable = new LinkedList<T>* [newCap];
    fill_bucket(newTable, newCap);

    for (int b = 0; b < array_size; b++) {
        for(int i = 0; i < hash_table[b]->size(); i++) {
            T value = hash_table[b]->get(i);
            _add(newTable, newCap, value);
        }
        delete hash_table[b];
    }
    
    delete[] hash_table;
    
    array_size = newCap;
    hash_table = newTable;
}


#endif // HASHSET_HPP


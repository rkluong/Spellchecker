// WordChecker.cpp
//
// ICS 46 Spring 2016
// Project #3: Set the Controls for the Heart of the Sun
//
// Replace and/or augment the implementations below as needed to meet
// the requirements.

#include "WordChecker.hpp"
#include <algorithm>

WordChecker::WordChecker(const Set<std::string>& words)
    : words{words}
{
}

bool WordChecker::wordExists(const std::string& word) const
{
    return words.contains(word);
}

std::vector<std::string> WordChecker::findSuggestions(const std::string& word) const
{
	std::vector<std::string> suggestions;
	
	if(wordExists(word))
		return suggestions;

	// swap adjacent pair
	for(int i = 1; i < word.size(); i++){
		std::string copy = word;
		std::swap(copy[i], copy[i-1]);
		if(wordExists(copy))
			suggestions.push_back(copy);
	}

	// insert every character
	for(char c = 'a'; c <= 'z'; c++){
		for(int i = 0; i <= word.size(); i++){
			std::string copy = word;
			copy.insert(i,1,c);
			if(wordExists(copy))
				suggestions.push_back(copy);
		}
	}

	//delete each characters
	for(int i = 0; i < word.size(); i++){
		std::string copy = "";
		for(int j = 0; j < word.size(); j++){
			if(i != j){
				copy += word[j];
			}
		}
		if(wordExists(copy))
			suggestions.push_back(copy);
	}

	//replace each character
	for(char c = 'a'; c <= 'z'; c++){
		for(int i = 0; i < word.size(); i++){
			std::string copy = word;
			copy[i] = c;
			if(wordExists(copy))
				suggestions.push_back(copy);
		}
	}

	//check pairs
	for(int i = 0; i < word.size()-1; i++){
		std::string str1 = word.substr(0, i+1);
		std::string str2 = word.substr(i+1);
		if(wordExists(str1) && wordExists(str2)){
			suggestions.push_back(str1);
			suggestions.push_back(str2);
		}
	}
	sort( suggestions.begin(), suggestions.end());
	suggestions.erase(unique(suggestions.begin(), suggestions.end()), suggestions.end());
	for(int i = 0; i < suggestions.size(); i++){
		std::cout << suggestions[i] << std::endl;
	}
    return suggestions;
}
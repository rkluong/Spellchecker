// BSTSet.hpp
//
// ICS 46 Spring 2016
// Project #3: Set the Controls for the Heart of the Sun
//
// A BSTSet is an implementation of a Set that is a binary search tree,
// albeit one that makes no attempt to remain balanced.  (You explicitly
// should not do any balancing here; do that in AVLSet instead, if you
// choose to work on that one.)
//
// You are not permitted to use the containers in the C++ Standard Library
// (such as std::set, std::map, or std::vector).  Instead, you'll need
// to implement your binary search tree using your own dynamically-allocated
// nodes, with pointers connecting them.

#ifndef BSTSET_HPP
#define BSTSET_HPP

#include "Set.hpp"
#include <stdlib.h>
#include <iostream>


template <typename T>
class BSTSet : public Set<T>
{
public:
    // Initializes a BSTSet to be empty.
    BSTSet();

    // Cleans up the BSTSet so that it leaks no memory.
    virtual ~BSTSet();

    // Initializes a new BSTSet to be a copy of an existing one.
    BSTSet(const BSTSet& s);

    // Assigns an existing BSTSet into another.
    BSTSet& operator=(const BSTSet& s);
    
    
    // isImplemented() should be modified to return true if you've
    // decided to implement a BSTSet, false otherwise.
    virtual bool isImplemented() const;
   
    // add() adds an element to the set.  If the element is already in the set,
    // this function has no effect.  This function runs in O(n) time when there
    // are n elements in the binary search tree, and is sometimes as fast as
    // O(log n) (when the tree is relatively balanced).
    virtual void add(const T& element);


    // contains() returns true if the given element is already in the set,
    // false otherwise.  This function runs in O(n) time when there
    // are n elements in the binary search tree, and is sometimes as fast as
    // O(log n) (when the tree is relatively balanced).
    virtual bool contains(const T& element) const;

    // size() returns the number of elements in the set.
    virtual unsigned int size() const;

private:
	struct Node{
        T value = NULL;
        Node* left_child = nullptr;
        Node* right_child = nullptr;
    };
    // Pointer to the root node
    struct Node* root;
    // Tree Node Count Size of Tree
    int count = 0;

    // helper to copy the Nodes for copy constructor
    void copy_nodes(struct Node* const source );
    // helper to destroy the tree
    void delete_tree(struct Node* cur_node);
    // helper to contains to check if element is in the tree
    bool _contains(struct Node* cur_node, const T& element) const;
    // helper to adding a node to the Tree
    void _add(struct Node* cur_node, const T& element);    
};


template <typename T>
BSTSet<T>::BSTSet()
{
	root = nullptr;
}

template <typename T>
void BSTSet<T>::delete_tree(struct Node* cur_node){
    if(cur_node == nullptr)
        return;
    if(cur_node->left_child != nullptr)
        delete_tree(cur_node->left_child);
    if(cur_node->right_child != nullptr)
        delete_tree(cur_node->right_child);
    delete(cur_node);
}

template <typename T>
BSTSet<T>::~BSTSet()
{
   
    delete_tree(root);
}

template <typename T>
void BSTSet<T>::copy_nodes(struct Node* const source){
   if(source == nullptr)
   		return;
   else
   {
   		add(source->value);
   		copy_nodes(source->left_child);
   		copy_nodes(source->right_child);
   }
}

template <typename T>
BSTSet<T>::BSTSet(const BSTSet& s)
{
	
 	copy_nodes(s.root);   
}

template <typename T>
BSTSet<T>& BSTSet<T>::operator=(const BSTSet& s)
{
    if(this != &s){
    	delete_tree(root);
    	root = nullptr;
    	copy_nodes(s.root);
    }
    return *this;
}


template <typename T>
bool BSTSet<T>::isImplemented() const
{
    return true;
}

template <typename T>
void BSTSet<T>::_add(struct Node* cur_node, const T& element){
    if(element == cur_node->value){
        return;
    }
    //left
    else if(element < cur_node->value){
        if(cur_node->left_child == nullptr){
            cur_node->left_child = new Node{element, nullptr, nullptr};
            count++;
            return;
        }
        else{
            _add(cur_node->left_child, element);
        }
    }
    else{
        if(cur_node->right_child == nullptr){
            cur_node->right_child = new Node{element, nullptr, nullptr};
            count++;
            return;
        }
        else{
            _add(cur_node->right_child, element);
        }
    }
}

template <typename T>
void BSTSet<T>::add(const T& element)
{
	if(size() == 0){
        root = new Node{element, nullptr, nullptr};
		count++;
		return;
	}
    else
        _add(root, element);
}

template <typename T>
bool BSTSet<T>::_contains(struct Node* cur_node, const T& element) const
{
    if(cur_node == nullptr)
        return false;
    if(cur_node->value == element)
        return true;
    if(_contains(cur_node->left_child, element))
        return true;
    if(_contains(cur_node->right_child, element))
        return true;
    return false;
}

template <typename T>
bool BSTSet<T>::contains(const T& element) const
{
    return _contains(root, element);
}


template <typename T>
unsigned int BSTSet<T>::size() const
{
   	return count;
}



#endif // BSTSET_HPP


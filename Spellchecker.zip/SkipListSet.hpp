// SkipListSet.hpp
//
// ICS 46 Spring 2016
// Project #3: Set the Controls for the Heart of the Sun
//
// A SkipListSet is an implementation of a Set that is a skip list, implemented
// as we discussed in lecture.  A skip list is a sequence of levels
//
// You are not permitted to use the containers in the C++ Standard Library
// (such as std::set, std::map, or std::vector), *except* that you can use
// std::vector to store your levels (e.g., pointers to the head node of each
// level) if you'd like.  Beyond that, you'll need to implement your own
// dynamically-allocated nodes with pointers connecting them.
//
// Each node should contain only two pointers: one to the node that follows it
// on the same level and another to the equivalent node on the level below it.
// Additional pointers use more memory but don't enable any techniques not
// enabled by the other two.
//
// A couple of utilities are included here: SkipListKind and SkipListKey.
// You can feel free to use these as-is and probably will not need to
// modify them.

#ifndef SKIPLISTSET_HPP
#define SKIPLISTSET_HPP
#include "HashSet.hpp"
#include "Set.hpp"
#include <random>
#include <vector>
#include <limits>

// SkipListKind indicates a kind of key: a normal one, the special key
// -INF, or the special key +INF.  It's necessary for us to implement
// the notion of -INF and +INF separately, since we're building a class
// template and not all types of keys would have a reasonable notion of
// -INF and +INF.


enum class SkipListKind
{
    Normal,
    NegInf,
    PosInf
};


// A SkipListKey represents a single key in a skip list.  It is possible
// to compare these keys using < or == operators (which are overloaded here)
// and those comparisons respect the notion of whether each key is normal,
// -INF, or +INF.


template <typename T>
class SkipListKey
{
public:
    SkipListKey(SkipListKind kind, const T& key);
    bool operator==(const SkipListKey& other) const;
    bool operator<(const SkipListKey& other) const;   
    SkipListKind kind;
    T key;
    
};


template <typename T>
SkipListKey<T>::SkipListKey(SkipListKind kind, const T& key)
    : kind{kind}, key{key}
{
}


template <typename T>
bool SkipListKey<T>::operator==(const SkipListKey& other) const
{
    return kind == other.kind
        && (kind != SkipListKind::Normal || key == other.key);
}


template <typename T>
bool SkipListKey<T>::operator<(const SkipListKey& other) const
{
    switch (kind)
    {
    case SkipListKind::NegInf:
        return other.kind != SkipListKind::NegInf;

    case SkipListKind::PosInf:
        return false;

    default: // SkipListKind::Normal
        return other.kind == SkipListKind::PosInf
            || (other.kind == SkipListKind::Normal && key < other.key);
    }
}
//generic node used in SkipLinkList and SkipListSet
template <typename T>
struct Node{
		SkipListKey<T> key;
		Node<T>* down;
		Node<T>* next;
};

//self implemented SkipLinkList
template <typename T>
class SkipLinkList: public LinkedList<T>
{
private:
	Node<T>* tail;
	Node<T>* head;
	int nodes = 2;
public:
    // Default Constructor
	SkipLinkList();
    // Default Deconstructor
    virtual ~SkipLinkList();
    // selection insert into the Linked List method
    void insert(const SkipListKey<T>& key);
    // returns the Size of the SkipLinkList
    virtual int size(){return nodes;};
    // check if the SkipList contains a certain key
    virtual bool contains(const SkipListKey<T>& key);
    // sets the down pointer in two different SkipLinkList 
    void set_down(SkipLinkList& lower, const SkipListKey<T>& search);
    // used for indexing the SkipLinkList
    SkipListKey<T>* get(int index);

    // helper function to destroy the SkipLinkList
    virtual void destroyAll();
    // returns the Head pointer to the LinkList
    Node<T>* get_head(){return head;};
	
};

template <typename T>
SkipLinkList<T>::SkipLinkList(){
	tail = new Node<T>{SkipListKey<T>(SkipListKind::PosInf, std::numeric_limits<T>::max()) ,nullptr, nullptr};
	head = new Node<T>{SkipListKey<T>(SkipListKind::NegInf, std::numeric_limits<T>::min()), nullptr, tail};
}

template <typename T>
void SkipLinkList<T>::destroyAll(){
	Node<T>* curr = head;

    while (curr != nullptr)
    {
        Node<T>* temp = curr;
        curr = curr->next;
        delete temp;
    }
}

template <typename T>
SkipLinkList<T>::~SkipLinkList(){
	destroyAll();
}

template<typename T>
void SkipLinkList<T>::insert(const SkipListKey<T>& key)
{
    //IMPORTANT NOTE the SKIPLISTSET will handle the nodes on the next level
    Node<T>* cur = head;
    if(contains(key))
        return;
    while(cur->next->key < key){  
        cur = cur->next;
    }
    Node<T>* _node = new Node<T>{key, nullptr, cur->next};
    cur->next = _node;
    ++nodes;
}


template<typename T>
bool SkipLinkList<T>::contains(const SkipListKey<T>& key){
	Node<T>* cur = head;
	while(cur != nullptr){
		if(cur->key == key)
			return true;
		cur = cur->next;
	}
    return false;
}
template <typename T>
SkipListKey<T>* SkipLinkList<T>::get(int index) {
    Node<T>* node = head;
    for (int i = 0; i < size(); i++) {
        if (i == index)
            return &(node->key);
        node = node->next;
    }
    return nullptr;
}

template<typename T>
void SkipLinkList<T>::set_down(SkipLinkList& lower, const SkipListKey<T>& search){
	Node<T>* cur = head;
	Node<T>* cur_two = lower.head;
	while(cur != nullptr){
		if(cur->key == search){
			while(cur_two != nullptr){
				if(cur_two->key == search){
					cur->down = cur_two;
				
					return;
				}
				cur_two = cur_two->next;
			}
		}
		cur = cur->next;
	}

}




template <typename T>
class SkipListSet : public Set<T>
{
public:
    // Initializes an SkipListSet to be empty.
    SkipListSet();

    // Cleans up the SkipListSet so that it leaks no memory.
    virtual ~SkipListSet();

    // Initializes a new SkipListSet to be a copy of an existing one.
    SkipListSet(const SkipListSet& s);

    // Assigns an existing SkipListSet into another.
    SkipListSet& operator=(const SkipListSet& s);


    // isImplemented() should be modified to return true if you've
    // decided to implement a SkipListSet, false otherwise.
    virtual bool isImplemented() const;


    // add() adds an element to the set.  If the element is already in the set,
    // this function has no effect.  This function runs in an expected time
    // of O(log n) (i.e., over the long run, we expect the average to be
    // O(log n)) with very high probability.
    virtual void add(const T& element);


    // contains() returns true if the given element is already in the set,
    // false otherwise.  This function runs in an expected time of O(log n)
    // (i.e., over the long run, we expect the average to be O(log n))
    // with very high probability.
    virtual bool contains(const T& element) const;


    // size() returns the number of elements in the set.
    virtual unsigned int size() const;
    
    // helper to copy SkipListSet
    void copyAll(const SkipListSet& other);

    std::vector<SkipLinkList<T>*> skiplist;

    int height = 0;
private:
    // each element is the pointer to a Linked List
    // resize changes the size of the Vector
    void resize();
    // helper method to destroy the SkipListSet
    void destroyAll();
};

template <typename T>
SkipListSet<T>::SkipListSet()
{
    height = 1;
    skiplist.push_back(new SkipLinkList<T>);
}

template <typename T>
SkipListSet<T>::~SkipListSet(){
    destroyAll();
}

template <typename T>
SkipListSet<T>::SkipListSet(const SkipListSet& s)
{
	copyAll(s);
}

template <typename T>
SkipListSet<T>& SkipListSet<T>::operator=(const SkipListSet& s)
{
    if(this != &s){
    	destroyAll();
    	copyAll(s);
    }
    return *this;
}

template <typename T>
void SkipListSet<T>::copyAll(const SkipListSet& other){
	SkipLinkList<T>* list = other.skiplist[0];

	height = other.height;
	//row
	for(int j = 0; j < other.height; j++){
		skiplist.push_back(new SkipLinkList<T>);
		//column only used on the FLOOR 0;
		for(int i = 0; i < list->size(); i++){
			//key for level 0 to check
			SkipListKey<T>* key = list->get(i);
			//cross copy checks the current level j to see if it contains the key on level 0
			if(other.skiplist[j]->contains(*key))
				skiplist[j]->insert(*key);
			//if the the current floor is not 0 then we need to set the downlinks
			if(j > 0)
				skiplist[j]->set_down(*skiplist[j-1], *key);

		}
	}

}

template <typename T>
void SkipListSet<T>::destroyAll(){
	for(int i = 0; i < skiplist.size(); i++){
		skiplist[i]->~SkipLinkList();
		delete skiplist[i];
	}
	skiplist.clear();
}
	


template <typename T>
void SkipListSet<T>::add(const T& element){
	int level = 1;
	SkipListKey<T> key(SkipListKind::Normal, element);
	if(skiplist[0]->contains(key) == false){
		skiplist[0]->insert(key);
		
		//random number generator 0 or 1
		std::random_device device;
		std::default_random_engine engine{device()};
		std::uniform_int_distribution<int> distribution{0,1};

		while(distribution(engine)){
			if(level == height){
				resize();
				height++;
				skiplist[level]->set_down(*skiplist[level-1], SkipListKey<T>(SkipListKind::NegInf, std::numeric_limits<T>::min()));
				skiplist[level]->set_down(*skiplist[level-1], SkipListKey<T>(SkipListKind::PosInf, std::numeric_limits<T>::max()));
			}
			skiplist[level]->insert(key);
			skiplist[level]->set_down(*skiplist[level-1], key);
			level++;
		}
	}
	return;
}

template <typename T>
bool SkipListSet<T>::isImplemented() const
{
    return true;
}

template <typename T>
bool SkipListSet<T>::contains(const T& element) const
{
	int level = height-1;
	SkipListKey<T> search(SkipListKind::Normal, element );
	Node<T>* start = skiplist[level]->get_head();
	while(true){
		if(start->key == search)
			return true;
		else if(search < start->next->key){
			if(level == 0)
				return false;
			start = start->down;
			level--;

		}
		else
			start = start->next;
	}

}


template <typename T>
unsigned int SkipListSet<T>::size() const
{
	return skiplist.size();
}

template <typename T>
void SkipListSet<T>::resize(){	
	skiplist.push_back(new SkipLinkList<T>);

}


#endif // SKIPLISTSET_HPP

